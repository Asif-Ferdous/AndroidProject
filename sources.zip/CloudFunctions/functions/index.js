const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp(functions.config().firebase);

exports.sendNotification = functions.database.ref('/messages/{studentID}/{pushID}')
    .onWrite(event => {
        const message = event.data.current.val();
        const sentfromadmin = message.admin
        var senderUid;
        var receiverUid = event.params.studentID;
        if (sentfromadmin == true) {
            senderUid = "admin";
            receiverUid = event.params.studentID;
        } else {
            senderUid = event.params.studentID;
            receiverUid = "admin"
        }

        const promises = [];

        if (senderUid == receiverUid) {
            //if sender is receiver, don't send notification
            promises.push(event.data.current.ref.remove());
            return Promise.all(promises);
        }

        const getInstanceIdPromise = admin.database().ref(`/users/${receiverUid}/iid`).once('value');

        return Promise.all([getInstanceIdPromise]).then(results => {
            const instanceId = results[0].val();
            console.log('notifying ' + receiverUid + ' about ' + message.msg + ' from ' + senderUid);

            var messageTitle;
            if (sentfromadmin == true) {
                messageTitle = "Message from FCI Admin"

            } else messageTitle = "Message from" + senderUid

            const payload = {
                notification: {
                    title: messageTitle,
                    body: message.msg,
                }
            };

            admin.messaging().sendToDevice(instanceId, payload)
                .then(function (response) {
                    console.log("Successfully sent message:", response);
                })
                .catch(function (error) {
                    console.log("Error sending message:", error);
                });
        });
    });

exports.newUser = functions.database.ref('/users/{studentID}')
    .onCreate(event => {
        console.log("newUser", event);
        var studentID = event.params.studentID;
        const promises = [];
        var promise = event.data.ref.parent.parent.child("validusers/" + studentID).set(null);
        promises.push(promise);
        var data = event.data.current.val();
        data.timestamp = Date.now();
        data.sorter = 9223372036854775807 - data.timestamp;
        console.log("after data man ", data);
        var promise2 = event.data.ref.parent.parent.child("msgsnippets/" + studentID).set(data);
        promises.push(promise2);
        return Promise.all(promises);
    });