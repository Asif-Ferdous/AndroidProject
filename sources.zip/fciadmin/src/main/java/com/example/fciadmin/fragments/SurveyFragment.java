package com.example.fciadmin.fragments;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.customtabs.CustomTabsIntent;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.fciadmin.R;
import com.example.fciadmin.databinding.FragmentSurveyBinding;
import com.example.fciadmin.model.Survey;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;


public class SurveyFragment extends Fragment {


    private static final String TAG = SurveyFragment.class.getSimpleName();
    private OnFragmentInteractionListener mListener;
    private FragmentSurveyBinding mViewData;

    public SurveyFragment() {

    }


    public static SurveyFragment newInstance() {
        SurveyFragment fragment = new SurveyFragment();
        return fragment;
    }


    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(
                    context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {
        mViewData = DataBindingUtil.inflate(inflater, R.layout.fragment_survey, container, false);
        Query query = FirebaseDatabase.getInstance().getReference().child("surveys").orderByChild(
                "sorter");
        FirebaseRecyclerOptions<Survey> options =
                new FirebaseRecyclerOptions.Builder<Survey>().setQuery(query, Survey.class)
                        .setLifecycleOwner(this)
                        .build();
        FirebaseRecyclerAdapter<Survey, SurveyViewHolder> adapter =
                new FirebaseRecyclerAdapter<Survey, SurveyFragment.SurveyViewHolder>(options) {
                    @Override
                    public void onDataChanged() {
                        super.onDataChanged();
                        mViewData.progressSurvey.setVisibility(View.GONE);
                    }

                    @Override
                    protected void onBindViewHolder(SurveyViewHolder holder,
                            int position,
                            Survey model) {
                        holder.surveyTitle.setText(model.getTitle());
                        holder.setLink(model.getLink());
                    }

                    @NonNull
                    @Override
                    public SurveyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
                        Log.d(TAG, "onCreateViewHolder: ");
                        return new SurveyViewHolder(LayoutInflater.from(parent.getContext())
                                .inflate(R.layout.item_survey, parent, false));
                    }
                };
        mViewData.surveyRecycler.setAdapter(adapter);
        return mViewData.getRoot();
    }


    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {

        void onFragmentInteraction(Uri uri);
    }

    public static class SurveyViewHolder extends RecyclerView.ViewHolder {

        private final AppCompatButton takeSurveyButton;
        private final AppCompatTextView surveyTitle;
        private String link;

        SurveyViewHolder(View itemView) {
            super(itemView);
            takeSurveyButton = itemView.findViewById(R.id.button_take_survey);
            surveyTitle = itemView.findViewById(R.id.survey_title);
        }

        public void setLink(String link) {
            this.link = link;
            takeSurveyButton.setOnClickListener(v -> {
                CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                CustomTabsIntent customTabsIntent = builder.build();
                customTabsIntent.launchUrl(v.getContext(), Uri.parse(link));
            });
        }
    }
}
