package com.example.fciadmin.fragments;

import android.Manifest;
import android.app.DownloadManager;
import android.content.Context;
import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.transition.TransitionManager;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.fciadmin.R;
import com.example.fciadmin.databinding.FragmentAnnouncementBinding;
import com.example.fciadmin.model.Announcement;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

import java.util.Calendar;
import java.util.Locale;

import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.EasyPermissions;


public class AnnouncementFragment extends Fragment implements FileDownloader {


    private static final String TAG = AnnouncementFragment.class.getSimpleName();
    private static final int RC_EXTERNAL_PERMISSION = 5;
    private OnFragmentInteractionListener mListener;
    private FragmentAnnouncementBinding mViewData;
    private String mAttachment;

    public AnnouncementFragment() {

    }


    public static AnnouncementFragment newInstance() {
        return new AnnouncementFragment();
    }


    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    public void downloadURL(String attachment) {
        mAttachment = attachment;
        downloadFile();
    }

    @AfterPermissionGranted(RC_EXTERNAL_PERMISSION)
    public void downloadFile() {
        String[] perms = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
        if (EasyPermissions.hasPermissions(getContext(), perms)) {
            DownloadManager downloadManager = (DownloadManager) getContext().getSystemService(
                    Context.DOWNLOAD_SERVICE);
            Uri uri = Uri.parse(mAttachment);
            DownloadManager.Request request =
                    new DownloadManager.Request(uri).setTitle(uri.getLastPathSegment()
                            .replaceFirst("-\\w+/", ""))
                            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                                    "")
                            .setNotificationVisibility(DownloadManager.Request
                                    .VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            downloadManager.enqueue(request);
            Toast.makeText(getContext(), "Downloading", Toast.LENGTH_SHORT).show();
        } else {
            EasyPermissions.requestPermissions(this,
                    getString(R.string.external_storage_rationale),
                    RC_EXTERNAL_PERMISSION,
                    perms);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(
                    context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {
        mViewData = DataBindingUtil.inflate(inflater,
                R.layout.fragment_announcement,
                container,
                false);
        Query query =
                FirebaseDatabase.getInstance().getReference().child("announcements").orderByChild(
                        "sorter");
        FirebaseRecyclerOptions<Announcement> options =
                new FirebaseRecyclerOptions.Builder<Announcement>().setQuery(query,
                        Announcement.class).setLifecycleOwner(this).build();
        FirebaseRecyclerAdapter<Announcement, AnnouncementViewHolder> adapter =
                new FirebaseRecyclerAdapter<Announcement, AnnouncementViewHolder>(options) {

                    int mExpandedPosition = -1;

                    @Override
                    public AnnouncementViewHolder onCreateViewHolder(ViewGroup parent,
                            int viewType) {
                        Log.d(TAG, "onCreateViewHolder: ");
                        return new AnnouncementViewHolder(LayoutInflater.from(parent.getContext())
                                .inflate(R.layout.item_announcement, parent, false));
                    }

                    @Override
                    public void onDataChanged() {
                        super.onDataChanged();
                        mViewData.progressAnnouncement.setVisibility(View.GONE);
                    }

                    @Override
                    protected void onBindViewHolder(AnnouncementViewHolder holder,
                            int position,
                            Announcement model) {
                        final boolean isExpanded = position == mExpandedPosition;
                        holder.titleTextView.setText(model.getTitle());
                        holder.bodyTextView.setMaxLines(isExpanded ? Integer.MAX_VALUE
                                : getResources().getInteger(R.integer.announcement_body_max_line));
                        holder.cardView.setActivated(isExpanded);
                        holder.bodyTextView.setText(model.getBody());
                        holder.buttonDownload.setVisibility(
                                model.getAttachment() != null && isExpanded ? View.VISIBLE
                                        : View.GONE);
                        if (model.getAttachment() != null) {
                            holder.setDownloadURL(AnnouncementFragment.this, model.getAttachment());
                        }
                        Calendar cal = Calendar.getInstance(Locale.ENGLISH);
                        cal.setTimeInMillis(model.getTimestamp());
                        String date = DateFormat.format("dd MMM yyyy", cal).toString();
                        holder.textAnnouncementDate.setText(date);
                        holder.itemView.setOnClickListener(v -> {
                            mExpandedPosition = isExpanded ? -1 : position;
                            TransitionManager.beginDelayedTransition(mViewData
                                    .announcementRecycler);
                            notifyDataSetChanged();
                        });
                    }
                };
        mViewData.announcementRecycler.setAdapter(adapter);
        return mViewData.getRoot();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {

        void onFragmentInteraction(Uri uri);
    }

    private static class AnnouncementViewHolder extends RecyclerView.ViewHolder {
        final AppCompatTextView titleTextView;
        final AppCompatTextView bodyTextView;
        final AppCompatButton buttonDownload;
        final AppCompatTextView textAnnouncementDate;
        final CardView cardView;

        AnnouncementViewHolder(View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.announcement_title);
            bodyTextView = itemView.findViewById(R.id.announcement_body);
            cardView = itemView.findViewById(R.id.announcement_container);
            buttonDownload = itemView.findViewById(R.id.button_download_attachment);
            textAnnouncementDate = itemView.findViewById(R.id.text_announcement_date);
        }

        public void setDownloadURL(FileDownloader downloader, String attachment) {
            buttonDownload.setOnClickListener(v -> downloader.downloadURL(attachment));
        }
    }
}
