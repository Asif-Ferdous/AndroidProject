package com.example.fciadmin.fragments;


import static android.app.Activity.RESULT_OK;

import android.Manifest;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.OpenableColumns;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.fciadmin.BuildConfig;
import com.example.fciadmin.R;
import com.example.fciadmin.databinding.FragmentChattingBinding;
import com.example.fciadmin.model.ChatItem;
import com.example.fciadmin.model.MessageSnippet;
import com.firebase.ui.common.ChangeEventType;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.jakewharton.rxbinding2.view.RxView;
import com.jakewharton.rxbinding2.widget.RxTextView;

import io.reactivex.Observable;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.EasyPermissions;

interface FileDownloader {
    void downloadURL(String attachment);
}

/**
 * A simple {@link Fragment} subclass.
 */
public class ChattingFragment extends Fragment implements FileDownloader {


    public static final String STUDENT_ID = "studentID";
    private static final String TAG = ChattingFragment.class.getSimpleName();
    private static final String STUDENT_NAME = "student_name";
    private static final int REQUEST_IMAGE = 4;
    private static final int RC_EXTERNAL_PERMISSION = 5;
    DatabaseReference mRef = FirebaseDatabase.getInstance().getReference();
    FirebaseAuth mAuth = FirebaseAuth.getInstance();
    private FragmentChattingBinding mViewData;
    private String sendingText;
    private CompositeDisposable mDisposable = new CompositeDisposable();
    private String mStudentName;
    private long mCategory;
    private String mFileName;
    private Uri mAttachmentURI;
    private String mAttachment;

    public ChattingFragment() {
        // Required empty public constructor
    }

    public static ChattingFragment newInstance(String studentID, String studentName) {
        ChattingFragment fragment = new ChattingFragment();
        Bundle bundle = new Bundle();
        bundle.putString(STUDENT_ID, studentID);
        bundle.putString(STUDENT_NAME, studentName);
        fragment.setArguments(bundle);
        return fragment;
    }

    public static Fragment newInstance() {

        ChattingFragment frag = new ChattingFragment();
        frag.setArguments(new Bundle());
        return frag;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE) {
            if (resultCode == RESULT_OK) {
                if (data != null) {
                    Uri returnUri = data.getData();

                    setAttachment(returnUri);
                }
            }
        }
    }

    private void setAttachment(Uri fileURI) {
        try {
            Cursor returnCursor = getActivity().getContentResolver().query(fileURI,
                    null,
                    null,
                    null,
                    null);
            int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            int sizeIndex = returnCursor.getColumnIndex(OpenableColumns.SIZE);
            returnCursor.moveToFirst();
            mFileName = returnCursor.getString(nameIndex);
            mViewData.itemAttachmentDetails.textFileName.setText(mFileName);
            mViewData.itemAttachmentDetails.textFileSize.setText(Long.toString(returnCursor.getLong(
                    sizeIndex)));
            mViewData.cardAttachment.setVisibility(View.VISIBLE);
            mAttachmentURI = fileURI;
            mViewData.buttonAttachFile.setVisibility(View.GONE);
            returnCursor.close();
        } catch (Exception e) {
            Snackbar.make(mViewData.buttonAttachFile,
                    "Failed to attach file",
                    Snackbar.LENGTH_SHORT);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mViewData = DataBindingUtil.inflate(inflater, R.layout.fragment_chatting, container, false);
        return mViewData.getRoot();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        String studentID = getArguments().getString(STUDENT_ID);
        if (studentID == null) {
            if (mAuth.getCurrentUser() != null) {
                String email = mAuth.getCurrentUser().getEmail();
                int index = email != null ? email.indexOf('@') : 0;
                studentID = email != null ? email.substring(0, index) : null;
            }
        }
        mStudentName = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString(
                MessageSnippet.STUDENT_NAME,
                null);
        if (getArguments().getString(STUDENT_NAME) != null) {
            mStudentName = getArguments().getString(STUDENT_NAME);
        }
        Log.d(TAG, String.valueOf("onViewCreated: " + mStudentName + (mStudentName == null)));

        mRef.child("users/" + studentID).addListenerForSingleValueEvent(new ValueEventListener() {


            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                mStudentName = dataSnapshot.child("name").getValue(String.class);
                mCategory = (long) dataSnapshot.child("category").getValue();
                Log.d(TAG, "onDataChange: " + mStudentName);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        Log.d(TAG, "onViewCreated: " + studentID);

        DatabaseReference dataRef = mRef.child("messages/" + studentID);
        DatabaseReference snipRef = mRef.child("msgsnippets/" + studentID);
        if (BuildConfig.FLAVOR == BuildConfig.FLAVOR_ADMIN) {
            snipRef.child("adminseen").setValue(true);
        }
        FirebaseRecyclerOptions<ChatItem> options =
                new FirebaseRecyclerOptions.Builder<ChatItem>().setQuery(dataRef, ChatItem.class)
                        .setLifecycleOwner(this)
                        .build();
        mViewData.recyclerChatting.setAdapter(new FirebaseRecyclerAdapter<ChatItem, ChatViewHolder>(
                options) {
            RecyclerView mRecyclerView;

            @Override
            public ChatViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
                int viewResID;
                if (viewType == ChatViewHolder.TYPE_SELF) {
                    viewResID = R.layout.item_self_message;
                } else viewResID = R.layout.item_remote_message;
                return new ChatViewHolder(LayoutInflater.from(parent.getContext())
                        .inflate(viewResID, parent, false));
            }

            @Override
            public int getItemViewType(int position) {
                ChatItem item = getItem(position);
                if (item.isAdmin() == (BuildConfig.FLAVOR == BuildConfig.FLAVOR_ADMIN)) {
                    return ChatViewHolder.TYPE_SELF;
                } else return ChatViewHolder.TYPE_NOT_SELF;
            }

            @Override
            public void onAttachedToRecyclerView(RecyclerView recyclerView) {
                super.onAttachedToRecyclerView(recyclerView);
                mRecyclerView = recyclerView;
            }

            @Override
            public void onChildChanged(ChangeEventType type,
                    DataSnapshot snapshot,
                    int newIndex,
                    int oldIndex) {
                super.onChildChanged(type, snapshot, newIndex, oldIndex);
                if (type == ChangeEventType.ADDED) {
                    if (mRecyclerView != null) {
                        mRecyclerView.smoothScrollToPosition(newIndex);
                    }
                }
            }

            @Override
            protected void onBindViewHolder(ChatViewHolder holder, int position, ChatItem model) {
                if (model.getAttachment() == null) {
                    holder.msg.setText(model.getMsg());
                    holder.clearOnClick();
                } else {
                    holder.msg.setText(model.getMsg().concat("\n\n\t\uD83D\uDCCE " + Uri.parse(model
                            .getAttachment()).getLastPathSegment().replaceFirst("-\\w+/", "")));
                    holder.setDownloadURL(ChattingFragment.this, model.getAttachment());
                }
            }
        });

        Observable<String> obSendMessageString =
                RxTextView.textChanges(mViewData.editSendMessage).skipInitialValue().map(
                        charSequence -> charSequence.toString().trim()).doOnNext(s -> sendingText =
                        s);
        Disposable subscribe = obSendMessageString.map(s -> !s.isEmpty()).doOnNext(RxView.enabled(
                mViewData.buttonSendMessage)).subscribe();
        mDisposable.add(subscribe);

        clearAttachment();
        mViewData.itemAttachmentDetails.buttonClearAttachment.setOnClickListener(v ->
                clearAttachment());
        mViewData.buttonAttachFile.setOnClickListener(v -> requestAttachment());

        mViewData.buttonSendMessage.setOnClickListener(v -> {
            mViewData.buttonSendMessage.setEnabled(false);
            DatabaseReference chattingRef = dataRef.push();
            if (mAttachmentURI != null) {
                StorageReference storageReference =
                        FirebaseStorage.getInstance().getReference().child(
                                chattingRef.getKey() + "/" + mFileName);
                mViewData.itemAttachmentDetails.progressFileUpload.setVisibility(View.VISIBLE);
                storageReference.putFile(mAttachmentURI).addOnCompleteListener(getActivity(),
                        task -> {
                            mViewData.itemAttachmentDetails.progressFileUpload.setVisibility(View
                                    .INVISIBLE);
                            if (task.isSuccessful()) {
                                String attachmentURL = task.getResult().getDownloadUrl().toString();
                                chattingRef.setValue(new ChatItem(System.currentTimeMillis(),
                                        sendingText,
                                        BuildConfig.FLAVOR == BuildConfig.FLAVOR_ADMIN,
                                        attachmentURL));
                                snipRef.setValue(new MessageSnippet(sendingText,
                                        mStudentName,
                                        mCategory,
                                        System.currentTimeMillis(),
                                        BuildConfig.FLAVOR == BuildConfig.FLAVOR_ADMIN));
                                clearAttachment();
                                mViewData.editSendMessage.setText("");
                            } else {
                                Log.w(TAG, "Could not upload", task.getException());
                                mViewData.buttonSendMessage.setEnabled(true);
                            }
                        });
            } else {
                ChatItem chatItem = new ChatItem(sendingText,
                        System.currentTimeMillis(),
                        BuildConfig.FLAVOR == BuildConfig.FLAVOR_ADMIN);
                chattingRef.setValue(chatItem);
                snipRef.setValue(new MessageSnippet(sendingText,
                        mStudentName,
                        mCategory,
                        System.currentTimeMillis(),
                        BuildConfig.FLAVOR == BuildConfig.FLAVOR_ADMIN));
                mViewData.editSendMessage.setText("");
            }
        });
        if (BuildConfig.FLAVOR != BuildConfig.FLAVOR_ADMIN) {
            mRef.child("users/" + studentID + "/iid").setValue(FirebaseInstanceId.getInstance()
                    .getToken());
        }
    }

    private void requestAttachment() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, REQUEST_IMAGE);
    }

    private void clearAttachment() {
        mAttachmentURI = null;
        mViewData.cardAttachment.setVisibility(View.GONE);
        mViewData.buttonAttachFile.setVisibility(View.VISIBLE);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        if (!mDisposable.isDisposed()) {
            mDisposable.dispose();
        }
    }

    public void sendDoneMessage() {
        mViewData.editSendMessage.setText("Issues has been resolved upto this point");
        mViewData.buttonSendMessage.performClick();
    }

    @Override
    public void downloadURL(String attachment) {
        mAttachment = attachment;
        downloadFile();
    }

    @AfterPermissionGranted(RC_EXTERNAL_PERMISSION)
    public void downloadFile() {
        String[] perms = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
        if (EasyPermissions.hasPermissions(getContext(), perms)) {
            DownloadManager downloadManager = (DownloadManager) getContext().getSystemService(
                    Context.DOWNLOAD_SERVICE);
            Uri uri = Uri.parse(mAttachment);
            DownloadManager.Request request =
                    new DownloadManager.Request(uri).setTitle(uri.getLastPathSegment()
                            .replaceFirst("-\\w+/", ""))
                            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                                    "")
                            .setNotificationVisibility(DownloadManager.Request
                                    .VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            downloadManager.enqueue(request);
            Toast.makeText(getContext(), "Downloading", Toast.LENGTH_SHORT).show();
        } else {
            EasyPermissions.requestPermissions(this,
                    getString(R.string.external_storage_rationale),
                    RC_EXTERNAL_PERMISSION,
                    perms);
        }
    }

    public static class ChatViewHolder extends RecyclerView.ViewHolder {
        public static final int TYPE_SELF = 1;
        public static final int TYPE_NOT_SELF = 3;
        public final AppCompatTextView msg;

        public ChatViewHolder(View itemView) {
            super(itemView);
            msg = itemView.findViewById(R.id.text_message);
        }

        public void setDownloadURL(FileDownloader downloader, String attachment) {
            itemView.setOnClickListener(v -> downloader.downloadURL(attachment));
        }

        public void clearOnClick() {
            itemView.setOnClickListener(null);
        }
    }
}
