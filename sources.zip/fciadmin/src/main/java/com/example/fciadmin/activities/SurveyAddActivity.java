package com.example.fciadmin.activities;

import android.app.ActionBar;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v4.app.TaskStackBuilder;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;

import com.example.fciadmin.R;
import com.example.fciadmin.fragments.AnnouncementEditFragment;

public class SurveyAddActivity extends AppCompatActivity implements AnnouncementEditFragment
        .OnFragmentInteractionListener {

    public static final String POST_REFERENCE = "dataRef";
    private static final String TAG = SurveyAddActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survey_add);
        ActionBar actionBar = getActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            Log.d(TAG, "onCreate: actionBar != null");
        }

        String dataRef = getIntent().getStringExtra(POST_REFERENCE);

        if (dataRef != null) {
            ((AnnouncementEditFragment) getSupportFragmentManager().findFragmentById(R.id.fragment))
                    .setReference(dataRef);
        }
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Log.d(TAG, "onOptionsItemSelected: Tapped Home Menu");
                Intent upIntent = NavUtils.getParentActivityIntent(this);
                if (NavUtils.shouldUpRecreateTask(this, upIntent)) {
                    TaskStackBuilder.create(this)
                            .addNextIntentWithParentStack(upIntent)
                            .startActivities();
                    Log.d(TAG, "onOptionsItemSelected: shouldUpRecreateTask");
                } else {
                    NavUtils.navigateUpTo(this, upIntent);
                }
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
