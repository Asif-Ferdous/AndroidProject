package com.example.fciadmin.model;

import android.support.annotation.NonNull;

/**
 * Created by borhan on 10/27/17.
 */

public class Survey {
    @NonNull
    String title;
    @NonNull
    String link;
    @NonNull
    long sorter;

    public Survey(@NonNull String title, @NonNull String link) {
        this.title = title;
        this.link = link;
        this.sorter = Long.MAX_VALUE - System.currentTimeMillis();
    }

    public Survey() {
    }

    @NonNull
    public long getSorter() {
        return sorter;
    }

    @NonNull
    public String getTitle() {
        return title;
    }

    @NonNull
    public String getLink() {
        return link;
    }
}
