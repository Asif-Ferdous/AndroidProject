package com.example.fciadmin.fragments;

import static android.app.Activity.RESULT_OK;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.fciadmin.R;
import com.example.fciadmin.adapter.PostNotification;
import com.example.fciadmin.databinding.FragmentAnnouncementEditBinding;
import com.example.fciadmin.model.Announcement;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.jakewharton.rxbinding2.widget.RxTextView;

import io.reactivex.Observable;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;


public class AnnouncementEditFragment extends Fragment {


    private static final String TAG = AnnouncementEditFragment.class.getSimpleName();
    private static final int REQUEST_IMAGE = 47;
    private OnFragmentInteractionListener mListener;
    private DatabaseReference mReference;
    private FragmentAnnouncementEditBinding mViewData;
    private CompositeDisposable mDisposable = new CompositeDisposable();
    private String mTitle = null;
    private String mBody = null;
    private Uri mAttachmentURI;
    private String mFileName;

    public AnnouncementEditFragment() {

    }


    public static AnnouncementEditFragment newInstance() {
        AnnouncementEditFragment fragment = new AnnouncementEditFragment();
        return fragment;
    }


    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE) {
            if (resultCode == RESULT_OK) {
                if (data != null) {
                    Uri returnUri = data.getData();

                    setAttachment(returnUri);
                }
            }
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(
                    context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {
        mViewData = DataBindingUtil.inflate(inflater,
                R.layout.fragment_announcement_edit,
                container,
                false);
        return mViewData.getRoot();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {

        // START: Don't read. All Rx processors here.
        Consumer<Boolean> setSaveButtonState =
                aBoolean -> mViewData.buttonAnnouncementSave.setEnabled(aBoolean);
        Function<CharSequence, String> textViewCharTrimmer =
                charSequence -> charSequence.toString().trim();
        Consumer<String> setTitleToField = string -> mTitle = string;
        Consumer<String> setBodyToField = string -> mBody = string;
        Function<String, Boolean> isNotEmpty = string -> !string.isEmpty();
        Consumer<Boolean> setErrorToTitle = aBoolean -> mViewData.inputTitle.setError(
                !aBoolean ? getString(R.string.warning_empty_announcement_title) : null);
        // END: Don't read. Read only if the following codes asks for it.

        clearAttachment();
        mViewData.itemAttachmentDetails.buttonClearAttachment.setOnClickListener(v ->
                clearAttachment());
        mViewData.buttonAddAttachment.setOnClickListener(v -> requestAttachment());

        Observable<String> obTitleString =
                RxTextView.textChanges(mViewData.editAnnouncementTitle).skipInitialValue().map(
                        textViewCharTrimmer).distinctUntilChanged().doOnNext(setTitleToField);
        Observable<Boolean> isTitleValid = obTitleString.map(isNotEmpty).doOnNext(setErrorToTitle);
        Observable<Boolean> obIsFormComplete = isTitleValid.doOnNext(setSaveButtonState);
        Observable<String> obBodyString =
                RxTextView.textChanges(mViewData.editAnnouncementBody).skipInitialValue().map(
                        textViewCharTrimmer).distinctUntilChanged().doOnNext(setBodyToField);

        Disposable b = obBodyString.subscribe();
        mDisposable.add(b);
        Disposable t = obIsFormComplete.subscribe();
        mDisposable.add(t);

        mViewData.buttonAnnouncementSave.setOnClickListener(v -> {
            if (mReference == null) {
                mReference =
                        FirebaseDatabase.getInstance().getReference().child("announcements").push();
            }

            if (mAttachmentURI != null) {
                StorageReference storageReference =
                        FirebaseStorage.getInstance().getReference().child(
                                mReference.getKey() + "/" + mFileName);
                storageReference.putFile(mAttachmentURI).addOnCompleteListener(getActivity(),
                        task -> {
                            if (task.isSuccessful()) {
                                String attachmentURL = task.getResult().getDownloadUrl().toString();
                                mReference.setValue(new Announcement(mTitle,
                                                mBody,
                                                attachmentURL,
                                                System.currentTimeMillis() /* ToDo: use server
                                                time */),
                                        (databaseError, databaseReference) -> getActivity()
                                                .finish());
                                new PostNotification(mTitle, mBody).execute();
                            } else {
                                Log.w(TAG,
                                        "Image upload task was not successful.",
                                        task.getException());
                            }
                        });
            } else {
                mReference.setValue(new Announcement(mTitle,
                                mBody,
                                null,
                                System.currentTimeMillis() /* ToDo: use server time */),
                        (databaseError, databaseReference) -> getActivity().finish());
                new PostNotification(mTitle, mBody).execute();
            }
        });
    }

    private void requestAttachment() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, REQUEST_IMAGE);
    }

    private void clearAttachment() {
        mAttachmentURI = null;
        mViewData.cardAttachment.setVisibility(View.GONE);
        mViewData.buttonAddAttachment.setVisibility(View.VISIBLE);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
        mDisposable.dispose();
    }

    private void setAttachment(Uri fileURI) {
        try {
            Cursor returnCursor = getActivity().getContentResolver().query(fileURI,
                    null,
                    null,
                    null,
                    null);
            int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            int sizeIndex = returnCursor.getColumnIndex(OpenableColumns.SIZE);
            returnCursor.moveToFirst();
            mFileName = returnCursor.getString(nameIndex);
            mViewData.itemAttachmentDetails.textFileName.setText(mFileName);
            mViewData.itemAttachmentDetails.textFileSize.setText(Long.toString(returnCursor.getLong(
                    sizeIndex)));
            mViewData.cardAttachment.setVisibility(View.VISIBLE);
            mAttachmentURI = fileURI;
            mViewData.buttonAddAttachment.setVisibility(View.GONE);
            returnCursor.close();
        } catch (Exception e) {
            Snackbar.make(mViewData.buttonAnnouncementSave,
                    "Failed to attach file",
                    Snackbar.LENGTH_SHORT);
        }
    }

    public void setReference(String reference) {
        mReference = FirebaseDatabase.getInstance().getReferenceFromUrl(reference);
    }


    public interface OnFragmentInteractionListener {

        void onFragmentInteraction(Uri uri);
    }
}
