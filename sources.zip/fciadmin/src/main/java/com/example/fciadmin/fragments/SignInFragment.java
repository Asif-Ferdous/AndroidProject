package com.example.fciadmin.fragments;

import android.content.Context;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.fciadmin.BuildConfig;
import com.example.fciadmin.R;
import com.example.fciadmin.activities.MainActivity;
import com.example.fciadmin.activities.SignInActivity;
import com.example.fciadmin.databinding.FragmentSignInBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.jakewharton.rxbinding2.widget.RxTextView;

import io.reactivex.Observable;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.BiFunction;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.functions.Predicate;


public class SignInFragment extends Fragment {


    private static final String TAG = SignInFragment.class.getSimpleName();
    private OnFragmentInteractionListener mListener;
    private FragmentSignInBinding mViewData;
    private String mStudentID;
    private String mPassword;
    private CompositeDisposable mDisposable = new CompositeDisposable();
    private FirebaseAuth mAuth;

    public SignInFragment() {

    }


    public static SignInFragment newInstance() {
        SignInFragment fragment = new SignInFragment();
        return fragment;
    }


    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
//            throw new RuntimeException(context.toString() + " must implement
// OnFragmentInteractionListener");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
        mAuth = FirebaseAuth.getInstance();
    }

    @Override
    public View onCreateView(LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {
        mViewData = DataBindingUtil.inflate(inflater, R.layout.fragment_sign_in, container, false);
        return mViewData.getRoot();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mViewData.buttonSignUp.setOnClickListener(v -> ((SignInActivity) getActivity())
                .switchFragment(
                v));

        if (BuildConfig.FLAVOR == BuildConfig.FLAVOR_ADMIN) {
            mViewData.buttonSignUp.setVisibility(View.GONE);
            mViewData.textNotAMember.setVisibility(View.GONE);
            mViewData.editStudentId.setInputType(InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        }
        // START: Don't read. All Rx processors here.
        Function<CharSequence, String> charSeqtoTrimmedString =
                charSequence -> charSequence.toString().trim();
        Predicate<String> lengthMustBeNine = s -> s.length() < 9;
        Consumer<String> setIDtoField = s -> mStudentID = s;
        Function<String, Boolean> idMatchesRegEx =
                s -> s.matches(getString(R.string.user_id_matcher));
        Consumer<Boolean> setErrorForStudentID = aBoolean -> {
            if (!aBoolean) {
                mViewData.inputStudentId.setError(getString(R.string.warning_invalid_student_id));
            } else mViewData.inputStudentId.setError(null);
        };

        Consumer<String> setPasswordToField = password -> {
            mPassword = password;
            Log.d(TAG, "onViewCreated: password " + password);
        };
        Consumer<Boolean> setErrorForPassword = aBoolean -> {
            if (!aBoolean) {
                mViewData.inputPassword.setError(getString(R.string.warning_password_empty));
            } else mViewData.inputPassword.setError(null);
        };
        Function<String, Boolean> isNotEmpty = s -> !s.isEmpty();
        BiFunction<Boolean, Boolean, Boolean> isAllTrue =
                (isIDValid, isPasswordNotEmpty) -> isIDValid && isPasswordNotEmpty;
        Consumer<Boolean> setSignInButtonStatus =
                isFormComplete -> mViewData.buttonSignIn.setEnabled(isFormComplete);
        // END: Don't read. Only read when referenced from following code.

        Observable<String> obStudentIDString =
                RxTextView.textChanges(mViewData.editStudentId)
                        .skipInitialValue()
                        .map(charSeqtoTrimmedString)
                        .distinctUntilChanged()
                        .skipWhile(lengthMustBeNine)
                        .doOnNext(setIDtoField);
        Observable<Boolean> obIsIDValid = obStudentIDString.map(idMatchesRegEx).doOnNext(
                setErrorForStudentID);
        Observable<String> obPasswordString = RxTextView.textChanges(mViewData.editPassword)
                .skipInitialValue()
                .map(CharSequence::toString)
                .distinctUntilChanged()
                .doOnNext(setPasswordToField);
        Observable<Boolean> obIsPasswordNotEmpty = obPasswordString.map(isNotEmpty).doOnNext(
                setErrorForPassword);
        Observable<Boolean> obFormComplete = Observable.combineLatest(obIsIDValid,
                obIsPasswordNotEmpty,
                isAllTrue).doOnNext(setSignInButtonStatus);
        mDisposable.add(obFormComplete.subscribe());

        mViewData.buttonSignIn.setOnClickListener(v -> signIn());
    }

    private void signIn() {
        mViewData.buttonSignIn.setEnabled(false);
        mViewData.progressSignIn.setVisibility(View.VISIBLE);
        mAuth.signInWithEmailAndPassword(mStudentID.concat("@student.id"), mPassword)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        startActivity(new Intent(getActivity(), MainActivity.class));
                        getActivity().finish();
                    } else {
                        mViewData.buttonSignIn.setEnabled(true);
                        mViewData.progressSignIn.setVisibility(View.GONE);
                    }
                })
                .addOnFailureListener(e -> {
                    if (e instanceof FirebaseAuthInvalidUserException) {
                        Toast.makeText(getContext(),
                                getString(R.string.error_user_does_nt_exist),
                                Toast.LENGTH_SHORT).show();
                    } else if (e instanceof FirebaseAuthInvalidCredentialsException) {
                        Toast.makeText(getContext(),
                                getString(R.string.error_invalid_password),
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
        mDisposable.dispose();
    }


    public interface OnFragmentInteractionListener {

        void onFragmentInteraction(Uri uri);
    }
}
