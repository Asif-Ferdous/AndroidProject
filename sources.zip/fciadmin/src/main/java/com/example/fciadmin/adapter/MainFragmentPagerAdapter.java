package com.example.fciadmin.adapter;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.example.fciadmin.BuildConfig;
import com.example.fciadmin.R;
import com.example.fciadmin.fragments.AnnouncementFragment;
import com.example.fciadmin.fragments.ChattingFragment;
import com.example.fciadmin.fragments.MessageFragment;
import com.example.fciadmin.fragments.SurveyFragment;

/**
 * Created by borhan on 10/24/17.
 */

public class MainFragmentPagerAdapter extends FragmentStatePagerAdapter {
    public static final int POSITION_ANNOUNCEMENT = 0;
    public static final int POSITION_MESSAGE = 1;
    public static final int POSITION_SURVEY = 2;
    private static final int FRAGMENT_COUNT = 3;
    private final Context mContext;

    public MainFragmentPagerAdapter(FragmentManager fm, Context context) {
        super(fm);
        mContext = context;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case POSITION_MESSAGE:
                switch (BuildConfig.FLAVOR) {
                    case BuildConfig.FLAVOR_ADMIN:
                        return MessageFragment.newInstance();
                    case BuildConfig.FLAVOR_STUDENT:
                        return ChattingFragment.newInstance();
                }
            case POSITION_ANNOUNCEMENT:
                return AnnouncementFragment.newInstance();
            case POSITION_SURVEY:
                return SurveyFragment.newInstance();
        }
        return null;
    }

    @Override
    public int getCount() {
        return FRAGMENT_COUNT;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case POSITION_MESSAGE:
                return mContext.getString(R.string.title_message_fragment);
            case POSITION_ANNOUNCEMENT:
                return mContext.getString(R.string.title_announcement_fragment);
            case POSITION_SURVEY:
                return mContext.getString(R.string.title_survey_fragment);
        }
        return null;
    }
}
