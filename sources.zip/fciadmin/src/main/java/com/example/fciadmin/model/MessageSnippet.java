package com.example.fciadmin.model;

import android.support.annotation.NonNull;

/**
 * Created by borhan on 10/28/17.
 */

public class MessageSnippet {
    public static final String STUDENT_NAME = "student_name";
    @NonNull
    String msg;
    @NonNull
    String name;
    boolean adminseen;
    long category;
    long timestamp;
    long sorter;

    public MessageSnippet() {
    }

    public MessageSnippet(@NonNull String msg,
            @NonNull String name,
            long category,
            long timestamp,
            boolean adminseen) {
        this(msg, name, timestamp);
        this.category = category;
        this.adminseen = adminseen;
    }

    public MessageSnippet(@NonNull String msg, @NonNull String name, long timestamp) {
        this(msg, timestamp);
        this.name = name;
    }

    public MessageSnippet(@NonNull String msg, long timestamp) {
        setTimestamp(timestamp);
        this.msg = msg;
    }

    public boolean isAdminseen() {
        return adminseen;
    }

    public long getCategory() {
        return category;
    }

    @NonNull
    public String getMsg() {
        return msg;
    }

    @NonNull
    public String getName() {
        return name;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
        this.sorter = Long.MAX_VALUE - timestamp;
    }

    public long getSorter() {
        return sorter;
    }
}
