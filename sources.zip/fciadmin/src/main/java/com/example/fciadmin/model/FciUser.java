package com.example.fciadmin.model;

import android.content.Context;
import android.support.annotation.Nullable;

import com.example.fciadmin.R;

/**
 * Created by borhan on 11/8/17.
 */

public class FciUser {
    public static final int UNDERGRADUATE = 1;
    public static final int POSTGRADUATE = 2;
    public static final int DIPLOMA = 3;
    public static final int FOUNDATION = 4;
    public static final int UNSUPPORTED = 0;

    @Nullable
    public static String getStringName(Context context, long CODE) {
        switch ((int) CODE) {
            case UNDERGRADUATE:
                return context.getString(R.string.category_undergraduate);
            case POSTGRADUATE:
                return context.getString(R.string.category_postgraduate);
            case DIPLOMA:
                return context.getString(R.string.category_diploma);
            case FOUNDATION:
                return context.getString(R.string.category_foundation);
        }
        return null;
    }

    public static int getBackgroundRes(long category) {
        switch (((int) category)) {
            case UNDERGRADUATE:
                return R.color.color_undergraduate;
            case POSTGRADUATE:
                return R.color.color_postgraduate;
            case DIPLOMA:
                return R.color.color_diploma;
            case FOUNDATION:
                return R.color.color_foundation;
        }
        return android.R.color.white;
    }
}
