package com.example.fciadmin.fragments;


import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.fciadmin.R;
import com.example.fciadmin.databinding.FragmentSurveyAddBinding;
import com.example.fciadmin.model.Survey;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.jakewharton.rxbinding2.widget.RxTextView;

import io.reactivex.Observable;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Function;

/**
 * A simple {@link Fragment} subclass.
 */
public class SurveyAddFragment extends Fragment {


    private FragmentSurveyAddBinding mViewData;
    private String mTitle = null;
    private String mURL = null;
    private CompositeDisposable mDisposable = new CompositeDisposable();
    private DatabaseReference mReference = null;

    public SurveyAddFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {
        mViewData = DataBindingUtil.inflate(inflater,
                R.layout.fragment_survey_add,
                container,
                false);
        return mViewData.getRoot();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mViewData.buttonSurveyCancel.setOnClickListener(v -> getActivity().finish());

        Function<CharSequence, String> charToTrimmedString =
                charSequence -> charSequence.toString().trim();
        Observable<String> obTitleString =
                RxTextView.textChanges(mViewData.editSurveyTitle).skipInitialValue().map(
                        charToTrimmedString).distinctUntilChanged().doOnNext(s -> mTitle = s);
        Observable<Boolean> obIsTitleValid =
                obTitleString.map(s -> !s.isEmpty()).doOnNext(aBoolean -> mViewData.inputSurveyTitle
                        .setError(
                                aBoolean ? null : getString(R.string.warning_empty_survey_title)));

        Observable<String> obURLString =
                RxTextView.textChanges(mViewData.editSurveyUrl).skipInitialValue().map(
                        charToTrimmedString).distinctUntilChanged().doOnNext(url -> mURL = url);
        Observable<Boolean> obIsURLValid = obURLString.map(s -> Patterns.WEB_URL.matcher(s)
                .matches()).doOnNext(aBoolean -> mViewData.inputSurveyUrl.setError(
                aBoolean ? null : getString(R.string.warning_invalid_link)));

        Observable<Boolean> obIsFormComplete = Observable.combineLatest(obIsTitleValid,
                obIsURLValid,
                (isTitleValid, isURLValid) -> isTitleValid && isURLValid)
                .doOnNext(aBoolean -> mViewData.buttonSurveySave.setEnabled(aBoolean));

        mViewData.buttonSurveySave.setOnClickListener(v -> {
            Survey survey = new Survey(mTitle, mURL);
            if (mReference == null) {
                mReference = FirebaseDatabase.getInstance().getReference().child("surveys").push();
            }
            mReference.setValue(survey).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    getActivity().finish();
                }
            });
        });

        mDisposable.add(obIsFormComplete.subscribe());
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mDisposable.dispose();
    }
}
