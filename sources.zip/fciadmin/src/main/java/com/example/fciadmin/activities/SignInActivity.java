package com.example.fciadmin.activities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.example.fciadmin.R;
import com.example.fciadmin.fragments.SignInFragment;
import com.example.fciadmin.fragments.SignUpFragment;

/**
 * Created by borhan on 10/28/17.
 */

public class SignInActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                SignInFragment.newInstance()).commit();
    }

    public void switchFragment(View view) {
        int id = view.getId();
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        switch (id) {
            case R.id.button_sign_in:
                ft.replace(R.id.fragment_container, SignInFragment.newInstance());
                break;
            case R.id.button_sign_up:
                ft.replace(R.id.fragment_container, SignUpFragment.newInstance());
                break;
        }
        ft.commit();
    }
}
