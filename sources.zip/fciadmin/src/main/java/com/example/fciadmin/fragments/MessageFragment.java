package com.example.fciadmin.fragments;

import android.content.Context;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.fciadmin.R;
import com.example.fciadmin.activities.ChatActivity;
import com.example.fciadmin.databinding.FragmentMessageBinding;
import com.example.fciadmin.model.FciUser;
import com.example.fciadmin.model.MessageSnippet;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;


public class MessageFragment extends Fragment {


    private static final String TAG = MessageFragment.class.getSimpleName();
    private OnFragmentInteractionListener mListener;
    private FragmentMessageBinding mViewData;

    public MessageFragment() {

    }


    public static MessageFragment newInstance() {
        MessageFragment fragment = new MessageFragment();
        return fragment;
    }


    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(
                    context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {
        mViewData = DataBindingUtil.inflate(inflater, R.layout.fragment_message, container, false);
        return mViewData.getRoot();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Query query =
                FirebaseDatabase.getInstance().getReference().child("msgsnippets").orderByChild(
                        "sorter");
        FirebaseRecyclerOptions<MessageSnippet> options =
                new FirebaseRecyclerOptions.Builder<MessageSnippet>().setQuery(query,
                        MessageSnippet.class).setLifecycleOwner(this).build();
        FirebaseRecyclerAdapter<MessageSnippet, MessageFragment.MessageViewHolder> adapter =
                new FirebaseRecyclerAdapter<MessageSnippet, MessageFragment.MessageViewHolder>(
                        options) {
                    @Override
                    public void onDataChanged() {
                        super.onDataChanged();
                        mViewData.progressMessage.setVisibility(View.GONE);
                    }

                    @Override
                    protected void onBindViewHolder(MessageFragment.MessageViewHolder holder,
                            int position,
                            MessageSnippet model) {
                        holder.studentName.setText(model.getName());
                        holder.messageSnippet.setText(model.getMsg());
                        long category = model.getCategory();
                        holder.textStudentCategory.setText(FciUser.getStringName(getContext(),
                                category));
                        holder.textStudentCategory.setBackgroundResource(FciUser.getBackgroundRes(
                                category));
                        holder.studentID.setText(getRef(position).getKey());
                        holder.textMsgDate.setText(DateUtils.getRelativeTimeSpanString(model
                                        .getTimestamp(),
                                System.currentTimeMillis(),
                                DateUtils.MINUTE_IN_MILLIS,
                                DateUtils.FORMAT_ABBREV_RELATIVE));
                        holder.textSeenTick.setVisibility(
                                model.isAdminseen() ? View.VISIBLE : View.GONE);
                        holder.setClick(getRef(position).getKey(), model.getName());
                    }

                    @NonNull
                    @Override
                    public MessageFragment.MessageViewHolder onCreateViewHolder(ViewGroup parent,
                            int viewType) {
                        Log.d(TAG, "onCreateViewHolder: ");
                        return new MessageFragment.MessageViewHolder(LayoutInflater.from(parent
                                .getContext())
                                .inflate(R.layout.item_message_snippet, parent, false));
                    }
                };
        mViewData.messageRecycler.setAdapter(adapter);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {

        void onFragmentInteraction(Uri uri);
    }

    public static class MessageViewHolder extends RecyclerView.ViewHolder {

        private final AppCompatTextView studentName;
        private final AppCompatTextView studentID;
        private final AppCompatTextView messageSnippet;
        private final AppCompatTextView textMsgDate;
        private final AppCompatTextView textStudentCategory;
        private final View textSeenTick;

        public MessageViewHolder(View itemView) {
            super(itemView);
            studentName = itemView.findViewById(R.id.student_name);
            studentID = itemView.findViewById(R.id.student_id);
            messageSnippet = itemView.findViewById(R.id.message_snippet);
            textMsgDate = itemView.findViewById(R.id.message_timestamp);
            textStudentCategory = itemView.findViewById(R.id.text_student_category);
            textSeenTick = itemView.findViewById(R.id.text_seen_tick);
        }

        public void setClick(String studentID, String studentName) {
            itemView.setOnClickListener(v -> {
                Intent intent = new Intent(v.getContext(), ChatActivity.class);
                intent.putExtra(ChatActivity.STUDENT_ID, studentID);
                intent.putExtra(ChatActivity.STUDENT_NAME, studentName);
                v.getContext().startActivity(intent);
            });
        }
    }
}
