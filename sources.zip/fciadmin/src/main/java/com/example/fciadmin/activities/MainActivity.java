package com.example.fciadmin.activities;

import static com.example.fciadmin.adapter.MainFragmentPagerAdapter.POSITION_ANNOUNCEMENT;
import static com.example.fciadmin.adapter.MainFragmentPagerAdapter.POSITION_MESSAGE;
import static com.example.fciadmin.adapter.MainFragmentPagerAdapter.POSITION_SURVEY;

import android.Manifest;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.customtabs.CustomTabsIntent;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.example.fciadmin.BuildConfig;
import com.example.fciadmin.R;
import com.example.fciadmin.adapter.MainFragmentPagerAdapter;
import com.example.fciadmin.databinding.ContentMainBinding;
import com.example.fciadmin.fragments.AnnouncementFragment;
import com.example.fciadmin.fragments.MessageFragment;
import com.example.fciadmin.fragments.SurveyFragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.EasyPermissions;

public class MainActivity extends AppCompatActivity implements NavigationView
        .OnNavigationItemSelectedListener,
        AnnouncementFragment.OnFragmentInteractionListener,
        MessageFragment.OnFragmentInteractionListener,
        SurveyFragment.OnFragmentInteractionListener,
        ViewPager.OnPageChangeListener {

    private static final String TAG = MainActivity.class.getSimpleName();
    private static final int RC_EXTERNAL_STORAGE = 7;
    private static final int REQUEST_FILE = 556;
    // FireBase Instance Variables
    FirebaseAuth mAuth = FirebaseAuth.getInstance();
    private ContentMainBinding mContentView;
    private FloatingActionButton mFab;
    private View.OnClickListener addAnnouncementListener;
    private View.OnClickListener addSurveyListener;
    private String mFilename;
    private Uri mAttachment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContentView = ContentMainBinding.bind(findViewById(R.id.content_main));
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mFab = findViewById(R.id.fab);
        mFab.setVisibility(View.GONE);
        addAnnouncementListener = v -> {
            startActivity(new Intent(this, AnnouncementEditActivity.class));
            overridePendingTransition(R.anim.slide_in_up, R.anim.stay);
        };
        addSurveyListener = v -> startActivity(new Intent(this, SurveyAddActivity.class));

        if (mAuth.getCurrentUser() == null) {
            Intent intent = new Intent(this, SignInActivity.class);
            startActivity(intent);
            finish();
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,
                drawer,
                toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        mContentView.viewpagerMain.setAdapter(new MainFragmentPagerAdapter
                (getSupportFragmentManager(),
                MainActivity.this));

        TabLayout tablayout = findViewById(R.id.tab_layout);
        tablayout.setupWithViewPager(mContentView.viewpagerMain);

        if (BuildConfig.FLAVOR == BuildConfig.FLAVOR_ADMIN) {
            mContentView.viewpagerMain.addOnPageChangeListener(this);
            mFab.setOnClickListener(addAnnouncementListener);
        }
        switch (BuildConfig.FLAVOR) {
            case BuildConfig.FLAVOR_ADMIN:
                FirebaseMessaging.getInstance().subscribeToTopic("Admin");
                break;
            case BuildConfig.FLAVOR_STUDENT:
                FirebaseMessaging.getInstance().subscribeToTopic("Student");
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.nav_course_list:
                switch (BuildConfig.FLAVOR) {
                    case BuildConfig.FLAVOR_STUDENT:
                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        builder.setMessage(R.string.confirm_download)
                                .setTitle(R.string.confirm_download_title)
                                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                                    String filename = "CourseList.pdf";
                                    downloadFromStorageRoot(filename);
                                })
                                .setNegativeButton(android.R.string.cancel,
                                        ((dialog, which) -> dialog.dismiss()));
                        AlertDialog dialog = builder.create();
                        dialog.show();
                        break;
                    case BuildConfig.FLAVOR_ADMIN:
                        AlertDialog.Builder builder2 = new AlertDialog.Builder(MainActivity.this);
                        builder2.setMessage(R.string.confirm_upload)
                                .setTitle(R.string.confirm_upload_title)
                                .setPositiveButton(android.R.string.ok, (dialog1, which) -> {
                                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                                    intent.setType("application/pdf");
                                    startActivityForResult(intent, REQUEST_FILE);
                                })
                                .setNegativeButton(android.R.string.cancel,
                                        ((dialog1, which) -> dialog1.dismiss()));
                        AlertDialog dialog2 = builder2.create();
                        dialog2.show();
                        break;
                }
                break;
            case R.id.nav_lecturer_list:
                String filename2 = "LecturerList.pdf";
                downloadFromStorageRoot(filename2);
                break;
            case R.id.nav_map:
                startActivity(new Intent(MainActivity.this, MapActivity.class));
                break;
            case R.id.nav_mmls_link:
                CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                CustomTabsIntent customTabsIntent = builder.build();
                customTabsIntent.launchUrl(MainActivity.this,
                        Uri.parse("https://mmls.mmu.edu.my/"));
                break;
            case R.id.nav_help:
                break;
            case R.id.nav_about:
                break;
            case R.id.nav_log_out:
                mAuth.signOut();
                startActivity(new Intent(MainActivity.this, SignInActivity.class));
                finish();
                break;
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void downloadFromStorageRoot(String filename2) {
        FirebaseStorage.getInstance()
                .getReference()
                .child(filename2)
                .getDownloadUrl()
                .addOnSuccessListener(attachment -> downloadUrl(attachment, filename2));
    }

    private void downloadUrl(Uri attachment, String filename) {
        mFilename = filename;
        mAttachment = attachment;
        downloadFile();
    }

    @AfterPermissionGranted(RC_EXTERNAL_STORAGE)
    private void downloadFile() {
        String[] perms = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
        if (EasyPermissions.hasPermissions(this, perms)) {
            DownloadManager downloadManager =
                    (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);

            DownloadManager.Request request =
                    new DownloadManager.Request(mAttachment).setNotificationVisibility(
                            DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "")
                            .setTitle(mFilename);
            downloadManager.enqueue(request);
            Toast.makeText(this, "Downloading", Toast.LENGTH_LONG).show();
        } else {
            EasyPermissions.requestPermissions(this,
                    getString(R.string.external_storage_rationale),
                    RC_EXTERNAL_STORAGE,
                    perms);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_FILE) {
            if (resultCode == RESULT_OK) {
                if (data != null) {
                    Uri returnUri = data.getData();

                    StorageReference storageReference =
                            FirebaseStorage.getInstance().getReference().child("CourseList.pdf");
                    Toast.makeText(MainActivity.this, "Upload Successful", Toast.LENGTH_LONG)
                            .show();
                    storageReference.putFile(returnUri).addOnCompleteListener(MainActivity.this,
                            task -> {
                                if (task.isSuccessful()) {
                                    Toast.makeText(MainActivity.this,
                                            "Upload Successful",
                                            Toast.LENGTH_LONG).show();
                                } else {
                                    Log.w(TAG,
                                            "File upload task was not successful.",
                                            task.getException());
                                }
                            });
                }
            }
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // Forward results to EasyPermissions
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        if (position == POSITION_ANNOUNCEMENT) {
            mFab.setVisibility(View.VISIBLE);
            mFab.setAlpha(1 - positionOffset);
        } else if (position == POSITION_MESSAGE) {
            if (positionOffset == 0) {
                mFab.setVisibility(View.GONE);
            } else {
                mFab.setVisibility(View.VISIBLE);
                mFab.setAlpha(positionOffset);
            }
        }
    }

    @Override
    public void onPageSelected(int position) {
        switch (position) {
            case POSITION_ANNOUNCEMENT:
                mFab.setOnClickListener(addAnnouncementListener);
                break;
            case POSITION_SURVEY:
                mFab.setOnClickListener(addSurveyListener);
        }
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }
}
