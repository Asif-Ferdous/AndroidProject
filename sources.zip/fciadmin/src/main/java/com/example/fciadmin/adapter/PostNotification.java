package com.example.fciadmin.adapter;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

/**
 * Created by borhan on 3/3/17.
 */

public class PostNotification extends AsyncTask {

    private static String TAG = "POSTnotification";

    String mTitle;
    String mBody;
    String imgURL;

    public PostNotification(String mTitle, String mBody, String imgURL) {
        this(mTitle, mBody);
        this.imgURL = imgURL;
    }

    public PostNotification(String mTitle, String mBody) {
        this.mTitle = mTitle;
        this.mBody = mBody;
    }

    @Override
    protected Object doInBackground(Object[] params) {
        try {
            URL url = new URL("https://fcm.googleapis.com/fcm/send");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setDoOutput(true);

            con.setRequestProperty("Content-Type", "application/json");
            con.setRequestProperty("Accept", "application/json");
            con.setRequestProperty("Authorization", "key=AIzaSyDvBD9YQ0-FruF9XYL-4NsnhINohdhVtSo");
            con.setRequestMethod("POST");
            con.connect();

            JSONObject notification = new JSONObject();
            notification.put("body", mBody);
            notification.put("title", mTitle);
            notification.put("click_action", "SHOW_ANNOUNCEMENTS");

            JSONObject data = new JSONObject();
            data.put("ALERT_TITLE", mTitle);
            data.put("ALERT_BODY", mBody);
            data.put("IMAGE_URL", imgURL);

            JSONObject payload = new JSONObject();
            payload.put("to", "/topics/Student");
            payload.put("notification", notification);
            payload.put("data", data);
            Log.d(TAG, "doInBackground: " + payload.toString());

            OutputStream os = con.getOutputStream();
            os.write(payload.toString().getBytes("UTF-8"));
            os.close();

            InputStream is = con.getInputStream();
            String responseString = new Scanner(is, "UTF-8").useDelimiter("\\A").next();
            is.close();

            JSONObject response = new JSONObject(responseString);

            Log.d(TAG, "doInBackground-response: " + response);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
    }
}
