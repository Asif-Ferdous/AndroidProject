package com.example.fciadmin.model;

/**
 * Created by borhan on 11/3/17.
 */

public class ChatItem {
    long timestamp;
    String msg;
    boolean admin;
    String attachment;

    public ChatItem(long timestamp, String msg, boolean admin, String attachment) {
        this(msg, timestamp, admin);
        this.attachment = attachment;
    }

    public ChatItem(String msg, long timestamp, boolean admin) {
        this.timestamp = timestamp;
        this.msg = msg;
        this.admin = admin;
    }

    public ChatItem() {

    }

    public String getAttachment() {
        return attachment;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public String getMsg() {
        return msg;
    }

    public boolean isAdmin() {
        return admin;
    }
}
