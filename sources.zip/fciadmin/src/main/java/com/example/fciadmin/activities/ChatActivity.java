package com.example.fciadmin.activities;

import android.app.ActionBar;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.PopupMenu;

import com.example.fciadmin.R;
import com.example.fciadmin.fragments.ChattingFragment;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ChatActivity extends AppCompatActivity {

    public static final String STUDENT_ID = "studentID";
    public static final String STUDENT_NAME = "student_name";
    private static final String TAG = ChatActivity.class.getSimpleName();
    private Menu mMainMenu;
    private long mStatus;
    private PopupMenu mPopMenu;
    private DatabaseReference mUserDataRef;
    private ChattingFragment mFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        String studentID = getIntent().getStringExtra(STUDENT_ID);
        String studentName = getIntent().getStringExtra(STUDENT_NAME);

        ActionBar actionBar = getActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            Log.d(TAG, "onCreate: actionBar != null");
            actionBar.setTitle(getIntent().getStringExtra(STUDENT_NAME));
        }
        mFragment = ChattingFragment.newInstance(studentID, studentName);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, mFragment)
                .commit();

        mUserDataRef = FirebaseDatabase.getInstance().getReference().child(
                "users/" + getIntent().getStringExtra(STUDENT_ID));
        mUserDataRef.addValueEventListener(

                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        Object value = dataSnapshot.child("status").getValue();
                        if (value != null) {
                            mStatus = (long) value;
                            invalidateOptionsMenu();
                        }
                        Log.d(TAG, "onDataChange: " + value);
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.admin_chatting, menu);
        mMainMenu = menu;
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        Log.d(TAG, "onPrepareOptionsMenu() called with: menu = [" + menu + "]");
        MenuItem item = menu.getItem(0);
        Log.d(TAG, "onPrepareOptionsMenu: " + (item.getItemId() == R.id.menu_issue_status));
        switch (((int) mStatus)) {
            case 0:
                item.setIcon(R.drawable.ic_course_list_24dp);
                item.getSubMenu().getItem(0).setEnabled(false);
                item.getSubMenu().getItem(2).setEnabled(true);
                break;
            case 1:
                item.setIcon(R.drawable.ic_working_on_it_24dp);
                item.getSubMenu().getItem(2).setEnabled(false);
                item.getSubMenu().getItem(0).setEnabled(true);
                break;
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.menu_working_on_it:
                mUserDataRef.child("status").setValue(1);
                break;
            case R.id.menu_done:
                mUserDataRef.child("status").setValue(0);
                mFragment.sendDoneMessage();
                break;
            case R.id.menu_not_working:
                mUserDataRef.child("status").setValue(0);
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
