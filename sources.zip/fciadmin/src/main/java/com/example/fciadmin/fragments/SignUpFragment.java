package com.example.fciadmin.fragments;

import static com.example.fciadmin.model.FciUser.DIPLOMA;
import static com.example.fciadmin.model.FciUser.FOUNDATION;
import static com.example.fciadmin.model.FciUser.POSTGRADUATE;
import static com.example.fciadmin.model.FciUser.UNDERGRADUATE;
import static com.example.fciadmin.model.FciUser.UNSUPPORTED;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.PopupMenu;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.fciadmin.BuildConfig;
import com.example.fciadmin.R;
import com.example.fciadmin.activities.MainActivity;
import com.example.fciadmin.activities.SignInActivity;
import com.example.fciadmin.databinding.FragmentSignUpBinding;
import com.example.fciadmin.model.FciUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jakewharton.rxbinding2.widget.RxTextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.functions.Function5;
import io.reactivex.functions.Predicate;


public class SignUpFragment extends Fragment {


    private static final String TAG = SignUpFragment.class.getSimpleName();
    FirebaseAuth mAuth;
    private OnFragmentInteractionListener mListener;
    private FragmentSignUpBinding mViewData;
    private CompositeDisposable mDisposable = new CompositeDisposable();
    private String mStudentID;
    private String mFullName;
    private String mPassword;
    private List<String> mValidUsers = new ArrayList<>();
    private int mCategory;

    public SignUpFragment() {

    }


    public static SignUpFragment newInstance() {
        SignUpFragment fragment = new SignUpFragment();
        return fragment;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
//            throw new RuntimeException(context.toString() + " must implement
// OnFragmentInteractionListener");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
        mAuth = FirebaseAuth.getInstance();
    }

    @Override
    public View onCreateView(LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {
        mViewData = DataBindingUtil.inflate(inflater, R.layout.fragment_sign_up, container, false);
        return mViewData.getRoot();
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (BuildConfig.FLAVOR == BuildConfig.FLAVOR_ADMIN) {
            mViewData.editStudentId.setInputType(InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        }
        mViewData.buttonSignIn.setOnClickListener(v -> ((SignInActivity) getActivity())
                .switchFragment(
                v));

        mViewData.editStudentId.setEnabled(false);
        mViewData.editCategory.setInputType(InputType.TYPE_NULL);
        mViewData.editCategory.setKeyListener(null);
        PopupMenu popupMenu = new PopupMenu(getContext(), mViewData.editCategory);
        new MenuInflater(getContext()).inflate(R.menu.category_menu, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();
            int category = UNSUPPORTED;
            switch (id) {
                case R.id.menu_diploma:
                    category = DIPLOMA;
                    break;
                case R.id.menu_foundation:
                    category = FOUNDATION;
                    break;
                case R.id.menu_postgraduate:
                    category = POSTGRADUATE;
                    break;
                case R.id.menu_undergraduate:
                    category = UNDERGRADUATE;
                    break;
            }
            String s = FciUser.getStringName(getContext(), category);
            if (s != null) {
                mViewData.editCategory.setText(s);
                mCategory = category;
                return true;
            }
            return false;
        });

        mViewData.editCategory.setOnTouchListener((v, event) -> {
            popupMenu.show();
            return true;
        });
        FirebaseDatabase.getInstance()
                .getReference()
                .child("validusers")
                .addListenerForSingleValueEvent(

                        new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                    mValidUsers.add(snapshot.getKey());
                                }
                                mViewData.editStudentId.setEnabled(true);
                                mViewData.progressDataLoad.setVisibility(View.GONE);
                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {

                            }
                        });

        // START: Don't Read. All Rx processors here.
        Predicate<String> lengthMustBeNine = s -> s.length() < 9;
        Function<CharSequence, String> charSeqtoTrimmedString =
                charSequence -> charSequence.toString().trim();
        Function<String, Boolean> isValidID =
                s -> s.matches(getString(R.string.user_id_matcher)) && mValidUsers.contains(s);
        Function<String, Boolean> isNotEmpty = s -> !s.isEmpty();
        Function<String, Boolean> doesMatchCriteria = s -> s.matches(
                "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\\s).{4,32}$");
        Function5<Boolean, Boolean, Boolean, Boolean, Boolean, Boolean> isAllTrue =
                (isIDValid, isCategoryValid, isNameValid, isPasswordValid, isMatchingPassword) ->
                        isIDValid && isNameValid && isPasswordValid && isMatchingPassword
                                && isCategoryValid;
        Consumer<String> setIDtoField = s -> mStudentID = s;
        Consumer<Boolean> setErrorForID = aBoolean -> mViewData.inputStudentId.setError(
                !aBoolean ? getString(R.string.warning_invalid_student_id) : null);
        Consumer<String> setFullNameToField = s -> mFullName = s;
        Consumer<Boolean> setErrorForName = aBoolean -> mViewData.inputFullName.setError(
                !aBoolean ? getString(R.string.warning_empty_name) : null);
        Consumer<String> setPasswordToField = password -> mPassword = password;
        Consumer<Boolean> setErrorForPassword = aBoolean -> mViewData.inputPassword.setError(
                !aBoolean ? getString(R.string.warning_invalid_password) : null);
        Consumer<Boolean> setPassworMatchError =
                aBoolean -> mViewData.inputConfirmPassword.setError(
                        !aBoolean ? getString(R.string.warning_passwords_no_match) : null);
        Consumer<Boolean> setSignUpButtonStatus =
                isFormComplete -> mViewData.buttonSignUp.setEnabled(isFormComplete);
        // END: Don't read. Read only if the following codes asks for it.

        Observable<String> obStudentIDString =
                RxTextView.textChanges(mViewData.editStudentId)
                        .skipInitialValue()
                        .map(charSeqtoTrimmedString)
                        .distinctUntilChanged()
                        .skipWhile(lengthMustBeNine)
                        .doOnNext(setIDtoField);
        Observable<Boolean> obIsIDValid = obStudentIDString.map(isValidID).doOnNext(setErrorForID);

        Observable<Boolean> obIsCategoryValid =
                RxTextView.textChanges(mViewData.editCategory).skipInitialValue().map(
                        charSeqtoTrimmedString).distinctUntilChanged().map(isNotEmpty);

        Observable<String> obFullNameString =
                RxTextView.textChanges(mViewData.editFullName).skipInitialValue().map(
                        charSeqtoTrimmedString).distinctUntilChanged().doOnNext(setFullNameToField);

        Observable<Boolean> obIsNameValid = obFullNameString.map(isNotEmpty).doOnNext(
                setErrorForName);

        Observable<String> obPasswordString = RxTextView.textChanges(mViewData.editPassword)
                .skipInitialValue()
                .map(CharSequence::toString)
                .distinctUntilChanged()
                .doOnNext(setPasswordToField);
        Observable<Boolean> obIsPasswordValid = obPasswordString.map(doesMatchCriteria).doOnNext(
                setErrorForPassword);

        Observable<String> obPasswordConfirmString =
                RxTextView.textChanges(mViewData.editConfirmPassword).skipInitialValue().map(
                        CharSequence::toString).distinctUntilChanged();
        Observable<Boolean> obDoesPasswordsMatch = Observable.combineLatest(obPasswordString,
                obPasswordConfirmString,
                String::matches).doOnNext(setPassworMatchError);

        Observable<Boolean> obFormComplete = Observable.combineLatest(obIsIDValid,
                obIsCategoryValid,
                obIsNameValid,
                obIsPasswordValid,
                obDoesPasswordsMatch,
                isAllTrue).doOnNext(setSignUpButtonStatus);
        mDisposable.add(obFormComplete.subscribe());
        mViewData.buttonSignUp.setOnClickListener(button -> signUp());
    }


    private void signUp() {
        mViewData.buttonSignUp.setEnabled(false);
        mViewData.progressSignUp.setVisibility(View.VISIBLE);
        mAuth.createUserWithEmailAndPassword(mStudentID.concat("@student.id"), mPassword)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Log.d(TAG, "onComplete: successfully created a user");

                        FirebaseDatabase.getInstance()
                                .getReference()
                                .child("users/" + mStudentID)
                                .updateChildren(new HashMap<String, Object>() {{
                                    put("name", mFullName);
                                    put("category", mCategory);
                                }})

                                .addOnCompleteListener(task1 -> {
                                    if (task1.isSuccessful()) {
                                        Intent intent = new Intent(getActivity(),
                                                MainActivity.class);
                                        startActivity(intent);
                                        getActivity().finish();
                                    }
                                });
                    } else {
                        mViewData.buttonSignUp.setEnabled(true);
                        mViewData.progressSignUp.setVisibility(View.INVISIBLE);
                        Log.w(TAG, "signUp: ", task.getException());
                    }
                })
                .addOnFailureListener(e -> {
                    if (e instanceof FirebaseAuthWeakPasswordException) {
                        Toast.makeText(getContext(),
                                getString(R.string.error_weak_password),
                                Toast.LENGTH_SHORT).show();
                    } else if (e instanceof FirebaseAuthUserCollisionException) {
                        Toast.makeText(getContext(),
                                getString(R.string.erron_already_signed_up),
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }


    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
        mDisposable.dispose();
    }


    public interface OnFragmentInteractionListener {

        void onFragmentInteraction(Uri uri);
    }
}
