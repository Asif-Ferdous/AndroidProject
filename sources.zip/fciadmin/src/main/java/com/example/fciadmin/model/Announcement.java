package com.example.fciadmin.model;

import android.support.annotation.NonNull;

/**
 * Created by borhan on 10/25/17.
 */

public class Announcement {
    @NonNull
    private String title;
    private String body;
    private String attachment;
    private long timestamp;
    private long sorter;

    public Announcement() {
    }

    public Announcement(long timestamp, String title, String attachment) {
        this(title, timestamp);
        this.attachment = attachment;
    }


    public Announcement(@NonNull String title, long timestamp) {
        this.title = title;
        this.timestamp = timestamp;
        this.sorter = Long.MAX_VALUE - timestamp;
    }

    public Announcement(String title, String body, String attachment, long timestamp) {
        this(title, body, timestamp);
        this.attachment = attachment;
    }

    public Announcement(String title, String body, long timestamp) {
        this(title, timestamp);
        this.body = body;
    }

    public String getTitle() {
        return title;
    }

    public String getBody() {
        return body;
    }

    public String getAttachment() {
        return attachment;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public long getSorter() {
        return sorter;
    }
}
